import React from "react";

function App() {
  return <h1>Hello from Eng_Hana AI!</h1>;
}

export default App;